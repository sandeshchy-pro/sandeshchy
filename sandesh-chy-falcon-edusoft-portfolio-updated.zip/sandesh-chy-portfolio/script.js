// EDIT THIS CONFIGURATION to personalize your website.
const SITE_CONFIG = {
  email: "falconedusoft@gmail.com",
  apps: [
    {
      name: "Puzzly – Puzzle & Brain Games",
      category: "Puzzle & Brain",
      description: "A collection of engaging puzzle and brain games designed to challenge logic, focus and problem-solving.",
      initials: "P",
      icon: "", // Add a public image URL for the app icon if desired.
      playUrl: "https://play.google.com/store/apps/details?id=com.falcon.puzzly"
    }
    // Add more published apps here. Use only real Play Store URLs.
    // Example:
    // { name:"Your App", category:"Education", description:"Short app description.",
    //   initials:"Y", icon:"https://example.com/icon.png", playUrl:"https://play.google.com/store/apps/details?id=YOUR.PACKAGE" }
  ],
  socials: {
    facebook: "",
    instagram: "",
    github: "",
    linkedin: ""
  }
};

const grid = document.getElementById("appsGrid");
const filters = document.getElementById("appFilters");
function renderApps(category = "All") {
  const apps = SITE_CONFIG.apps.filter(app => category === "All" || app.category === category);
  grid.innerHTML = apps.length ? apps.map(app => `
    <article class="app-card">
      <div class="app-card-top">
        <div class="app-icon">${app.icon ? `<img src="${escapeHTML(app.icon)}" alt="${escapeHTML(app.name)} icon" loading="lazy">` : escapeHTML(app.initials || app.name.charAt(0))}</div>
        <div><span class="app-category">${escapeHTML(app.category)}</span><h3>${escapeHTML(app.name)}</h3></div>
      </div>
      <p>${escapeHTML(app.description)}</p>
      <a class="app-link" href="${safeURL(app.playUrl)}" target="_blank" rel="noopener noreferrer">View on Google Play <i data-lucide="external-link"></i></a>
    </article>`).join("") : `<p class="empty-state">No apps in this category yet. Check back soon.</p>`;
  if (window.lucide) lucide.createIcons();
}
function escapeHTML(value = "") {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function safeURL(value = "") {
  try { const url = new URL(value); return ["https:","http:"].includes(url.protocol) ? escapeHTML(url.href) : "#"; }
  catch { return "#"; }
}
renderApps();
filters.addEventListener("click", e => {
  const button = e.target.closest("[data-filter]");
  if (!button) return;
  filters.querySelectorAll(".filter").forEach(b => b.classList.toggle("active", b === button));
  renderApps(button.dataset.filter);
});

const menuToggle = document.getElementById("menuToggle");
const nav = document.getElementById("mainNav");
menuToggle.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
  menuToggle.innerHTML = open ? '<i data-lucide="x"></i>' : '<i data-lucide="menu"></i>';
  lucide.createIcons();
});
nav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
  nav.classList.remove("open"); menuToggle.setAttribute("aria-expanded","false");
  menuToggle.innerHTML = '<i data-lucide="menu"></i>'; lucide.createIcons();
}));

const themeToggle = document.getElementById("themeToggle");
const savedTheme = localStorage.getItem("falcon-theme");
if (savedTheme === "light") document.body.classList.add("light");
themeToggle.addEventListener("click", () => {
  document.body.classList.toggle("light");
  localStorage.setItem("falcon-theme", document.body.classList.contains("light") ? "light" : "dark");
});
document.getElementById("year").textContent = new Date().getFullYear();
document.getElementById("emailLink").textContent = SITE_CONFIG.email;
document.getElementById("emailLink").href = "mailto:" + SITE_CONFIG.email;

Object.entries(SITE_CONFIG.socials).forEach(([network, url]) => {
  if (!url) return;
  const link = document.querySelector(`.social-links a[aria-label^="${network}"]`);
  if (link) { link.href = safeURL(url); link.target = "_blank"; link.rel = "noopener noreferrer"; link.classList.remove("social-placeholder"); }
});
document.querySelectorAll(".social-placeholder").forEach(link => link.addEventListener("click", e => e.preventDefault()));

const toTop = document.getElementById("toTop");
window.addEventListener("scroll", () => {
  toTop.classList.toggle("show", window.scrollY > 500);
  const sections = [...document.querySelectorAll("main section[id]")];
  let current = "home";
  sections.forEach(section => { if (window.scrollY >= section.offsetTop - 150) current = section.id; });
  nav.querySelectorAll("a").forEach(a => a.classList.toggle("active", a.getAttribute("href") === "#" + current));
}, { passive: true });
toTop.addEventListener("click", () => window.scrollTo({top:0,behavior:"smooth"}));

document.getElementById("contactForm").addEventListener("submit", e => {
  e.preventDefault();
  const form = e.currentTarget;
  if (!form.reportValidity()) return;
  const data = new FormData(form);
  const subject = encodeURIComponent(data.get("subject") || "Website enquiry from " + data.get("name"));
  const body = encodeURIComponent(`Name: ${data.get("name")}\nEmail: ${data.get("email")}\n\n${data.get("message")}`);
  document.getElementById("formNote").textContent = "Your email app should open with the message prepared.";
  window.location.href = `mailto:${SITE_CONFIG.email}?subject=${subject}&body=${body}`;
});
if (window.lucide) lucide.createIcons();
