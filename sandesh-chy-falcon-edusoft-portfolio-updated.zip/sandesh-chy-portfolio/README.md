# Sandesh Chy / Falcon EduSoft portfolio

A responsive static portfolio website built with HTML, CSS and vanilla JavaScript.

## Files
- `index.html` — homepage and all portfolio sections
- `styles.css` — responsive design, dark/light themes
- `script.js` — app portfolio, theme, navigation and contact form
- `privacy.html` — editable starter privacy policy

## Customize before publishing
1. Open `script.js` and replace `SITE_CONFIG.email` with your real email.
2. Add your published apps to `SITE_CONFIG.apps`. Use real Play Store URLs, app names, descriptions and icon image URLs.
3. Add your social profile URLs to `SITE_CONFIG.socials`.
4. Replace the privacy policy content to accurately describe your real website and services.
5. Add your own profile photo, logo and domain metadata if desired.

## Run locally
Open `index.html` in a modern browser. For best results, use a local static server.

## Deploy
Upload the folder contents to Cloudflare Pages, Netlify or GitHub Pages. No build step is required.

## Notes
- The contact form uses `mailto:`. It does not send messages through a backend.
- The website does not invent app ratings, download counts, testimonials or credentials.
- The app showcase starts with the Puzzly Play Store listing supplied for this project. Add other verified Play Store links in `script.js`.
- Google Fonts and Lucide icons are loaded from third-party CDNs.


## Updated contact and branding
- Uses the supplied Falcon EduSoft logo at `assets/falcon-edusoft-logo.png`.
- Email: `falconedusoft@gmail.com`.
- WhatsApp: `https://wa.me/9779715000040`.
- Telegram: `https://t.me/+9779715000040` (availability depends on Telegram phone-number privacy settings).
- Privacy policy describes the current static-site features. Revisit it if analytics, a backend, cookies or other services are introduced.
